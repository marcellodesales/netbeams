require "test/unit"

class DbTest < Test::Unit::TestCase
  def setup
  end
  
  def teardown
  end
  
  def test_true
    assert(true, 'It Works !')
  end
  
end
